#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

char upAlp[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; 
char incript(char *message, char *key_Alf, char *inc)
{
clock_t time;
time = clock();
printf("\nIncription: ");
int letter;
	for (int i=0; i<strlen(message); i++)
	for (int j=0; j<strlen(key_Alf); j++)
		{
			if (message[i]==upAlp[j])
			{
				inc[i]=key_Alf[j];
			}
		}
	printf("%s", inc);
	time = clock() -time;
	printf("        Function time: ");
	printf("%f", (double)time/CLOCKS_PER_SEC);
}

char decript(char *message, char *key_Alf, char *inc)
{
clock_t time;
time = clock();
printf("\nDecription: ");
	for (int i=0; i<strlen(message); i++)
	for (int j=0; j<strlen(key_Alf); j++)
	{
		if (inc[i]==key_Alf[j])
		{
			message[i]=upAlp[j];
			printf("%c", message[i]);
		}
	}
	time = clock() -time;
	printf("        Function time: ");
	printf("%f", (double)time/CLOCKS_PER_SEC);
}

int main()
{
clock_t time;
time = clock();
char key_Alf[60];
char inc[60];
char message[25];
printf("Enter message: ");
scanf("%s", &message);
printf("Enter a keyword: ");
scanf("%s", &key_Alf);
strcat(key_Alf,upAlp);
	for (int i=0; i<strlen(key_Alf); i++)
	for (int j=i+1; j<strlen(key_Alf); j++)
	{
		if (key_Alf[i]==key_Alf[j])
		{
			for(int k=j; k<strlen(key_Alf); k++)
			{
				key_Alf[k]=key_Alf[k+1];
			}
		}
	}

	incript(message, key_Alf, inc);
	decript(message, key_Alf, inc);
	time = clock() -time;
printf("\nTotal program time: ");
printf("%f", (double)time/CLOCKS_PER_SEC);
printf("\n");

}

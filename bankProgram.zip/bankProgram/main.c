#include <stdio.h>
#include <string.h>

typedef struct{
	char name[256];
	char nameOfBank[256];
	long int account;
	char operation[256];
	float amount;
}CLIENT;

int getNumOfClients(FILE *fp)
{
	
	int numOfClients = 0; 
	CLIENT client;
	char ch;
	while(1)
	{
		ch=fscanf(fp, "%s %s %li %s %f", client.name, client.nameOfBank, &client.account, client.operation, &client.amount);
		if(ch==EOF)
			break;
		numOfClients++;
		//fprintf(stdout, "%s %s %li %s %.2f\n", client.name, client.nameOfBank, client.account, client.operation, client.amount);
	}
	rewind(fp);
	return numOfClients;
}
//CLIENT * getStructOfClients(int numOfClients)
//{
//	CLIENT clients[numOfClients];
//	FILE *fp;
//	char ch;	
//	for(int i = 0; i < numOfClients; i++)
//	{
//		ch=fscanf(fp, "%s %s %li %s %f", clients[i].name, clients[i].nameOfBank, &clients[i].account, clients[i].operation, &clients[i].amount);
//		if(ch==EOF)
//			break;
//		fprintf(stdout, "%s %s %li %s %.2f\n", clients[i].name, clients[i].nameOfBank, clients[i].account, clients[i].operation, clients[i].amount);
//	}
//	fclose(fp);
//	
//	return clients;
//}
void outputFile1(CLIENT *clients, int numOfClients)
{
	FILE *fp;
	int id = 1, numOfTransaction = 0, i = 0;
	float sum = 0;
	fp = fopen("outfile", "w+");
	while(i < numOfClients)
	{
		sum = clients[i].amount;
		numOfTransaction = 1;
		for(int j = i+1; j < numOfClients; j++)
			if(strcmp(clients[i].name, clients[j].name) == 0)
			{
				sum += clients[j].amount;
				numOfTransaction++;
			}
			else
			{
				i += j-i-1;
				break;
			}
		fprintf(fp, "%i %s %i %.2f\n", id, clients[i].name, numOfTransaction, sum);
		id++;
		i++;
	}
	fclose(fp);
}
void outputFile2(CLIENT *clients, int numOfClients)
{
	FILE *fp;
	int pay = 0, extract = 0;
	for(int i = 0; i < numOfClients; i++)
		if(strcmp(clients[i].operation, "pay") == 0)
			pay++;
		else
			extract++;
	fp = fopen("outfile2", "w+");
	fprintf(fp, "1 pay %i\n", pay);
	fprintf(fp, "2 extract %i\n", extract);
	fclose(fp);
}

int main(){
	
	FILE *fp;
	int numOfClients;
	char ch;	

	fp = fopen("infile", "r");
	if(fp == NULL){
		fprintf(stdout, "no such file\n");
		fclose(fp);
		return 0;
	}		
	
	numOfClients = getNumOfClients(fp);

	CLIENT clients[numOfClients];
	for(int i = 0; i < numOfClients; i++)
	{
		ch=fscanf(fp, "%s %s %li %s %f", clients[i].name, clients[i].nameOfBank, &clients[i].account, clients[i].operation, &clients[i].amount);
		if(ch==EOF)
			break;
		fprintf(stdout, "%s %s %li %s %.2f\n", clients[i].name, clients[i].nameOfBank, clients[i].account, clients[i].operation, clients[i].amount);
	}
	fclose(fp);
	
	
	//outfile1
	outputFile1(clients, numOfClients);

	//outfile2
	outputFile2(clients, numOfClients);

	return 0;

}
